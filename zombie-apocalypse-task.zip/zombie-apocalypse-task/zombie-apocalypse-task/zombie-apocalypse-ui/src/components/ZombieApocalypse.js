import React, { useState } from "react";
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { Typography } from "@material-ui/core";
import Fab from '@material-ui/core/Fab';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import axios from "axios";

function ZombieApocalypse() {
    const [dimension, setDimesion] = useState(0);
    const [xZ, setXZ] = useState(0);
    const [yZ, setYZ] = useState(0);
    const [xC, setXC] = useState(0);
    const [yC, setYC] = useState(0);
    const [zombiePosition, setZombiePosition] = useState({});
    const [creaturesPosition, setCreaturesPosition] = useState([]);
    const [direction, setDirection] = useState("UP")
    const [zombieMoves, setZombieMoves] = useState([]);
    const [error, setError] = useState("")
    const [responseData, setResponseData] = useState(null)
    const [apiCallSuccess, setApiCallSucces] = useState(false);
    const [creatures, setCreatures] = useState("");
    const [zombies, setZombies] = useState("");

    const handleDimensionChange = (event) => {
        setDimesion(event.target.value);
    };

    const handleXZChange = (event) => {
        setXZ(event.target.value);
    }

    const handleYZChange = (event) => {
        setYZ(event.target.value);
    }

    const handleXCChange = (event) => {
        setXC(event.target.value);
    }

    const handleYCChange = (event) => {
        setYC(event.target.value);
    }

    const handleAddZombiePosition = () => {
        setZombiePosition({ "x": xZ, "y": yZ })
    }

    const handleAddCreaturePosition = () => {
        setCreaturesPosition([...creaturesPosition, { "x": xC, "y": yC }])
    }

    const handleMoveChange = (event) => {
        setDirection(event.target.value)
    }

    const handleAddZombieMove = () => {
        setZombieMoves([...zombieMoves, direction])
    }

    const reset = () => {
        setDimesion(0);
        setXZ(0);
        setYZ(0);
        setXC(0);
        setYC(0);
        setZombiePosition({});
        setCreaturesPosition([]);
        setDirection("UP");
        setZombieMoves([]);
        setError("");
        setResponseData(null);
        setApiCallSucces(false);
        setCreatures("");
        setZombies("");
    }

    const simulate = () => {
        if (dimension <= 1) {
            setError("Dimension should be greater than 1");
            return;
        }
        if (xZ >= dimension || xZ < 0 || yZ >= dimension || yZ < 0) {
            setError("Zombie coordinates should be > 0 and < " + dimension);
            return;
        }
        if (zombiePosition && Object.keys(zombiePosition).length === 0 && zombiePosition.constructor === Object) {
            setError("Zombie coordinates is mandatory");
            return;
        }

        if (creaturesPosition && creaturesPosition.length === 0) {
            setError("Creature coordinates is mandatory");
            return;
        }
        if (creaturesPosition.length !== 0) {
            let flag = false;
            for (let i = 0; i < creaturesPosition.length; i++) {
                let x = creaturesPosition[i].x;
                let y = creaturesPosition[i].y;
                if (x >= dimension || x < 0 || y >= dimension || y < 0) {
                    setError("Creature coordinates should be > 0 and < " + dimension);
                    flag = true;
                    break;
                }
            }
            if (flag) {
                return;
            }
        }

        console.log(zombieMoves.length)
        if (zombieMoves && zombieMoves.length === 0) {
            setError("Zombie moves is mandatory");
            return;
        }

        setError("");
        axios.post("http://localhost:8080/zombie/dimension/" + dimension, {
            "initialZombiePosition": zombiePosition,
            "initialCreaturesPosition": creaturesPosition,
            "zombieMoves": zombieMoves
        })
            .then(function (response) {
                let res = response.data;
                setResponseData(response.data)
                setApiCallSucces(true);

                let zombies = "";
                let creatures = "";
                for (let i = 0; i < res.matrix.length; i++) {
                    for (let j = 0; j < res.matrix.length; j++) {
                        if (res.matrix[i][j] === 2) {
                            creatures += "(" + i + "," + j + ") ";
                        }
                        if (res.matrix[i][j] === 3) {
                            zombies += "(" + i + "," + j + ") ";
                        }
                    }
                }

                setCreatures(creatures);
                setZombies(zombies);
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    return (
        <>
            <span style={{ color: "red" }}>{error !== "" ? error : ""}</span>
            <Grid container style={{ color: "gray", marginTop: 25, marginLeft: 25 }}>
                <Typography>Dimension of matrix : <span>{dimension}</span></Typography>
                <Grid item xs={12} style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    <TextField
                        id="standard-number"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        variant="filled"
                        size="small"
                        value={dimension}
                        onChange={handleDimensionChange}
                    />
                </Grid>
            </Grid>
            <Grid container style={{ color: "gray", marginTop: 25, marginLeft: 25 }}>
                <Typography>Initial position of Zombie : {JSON.stringify(zombiePosition)}</Typography>
                <Grid item xs={12} style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    <TextField
                        id="standard-number"
                        label="x"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        variant="filled"
                        size="small"
                        style={{ width: 100 }}
                        value={xZ}
                        onChange={handleXZChange}
                    />
                    <TextField
                        id="standard-number"
                        label="y"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        variant="filled"
                        size="small"
                        style={{ width: 100, marginLeft: 10 }}
                        value={yZ}
                        onChange={handleYZChange}
                    />
                    <Tooltip title="Add Zombie Position" aria-label="add">
                        <Fab color="primary" style={{ margin: 10, width: 45, height: 40 }} onClick={handleAddZombiePosition}>
                            <AddIcon size="small" />
                        </Fab>
                    </Tooltip>
                </Grid>
            </Grid>
            <Grid container style={{ color: "gray", marginTop: 25, marginLeft: 25 }}>
                <Typography>Positions of Creatures : {JSON.stringify(creaturesPosition)}</Typography>
                <Grid item xs={12} style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    <TextField
                        id="standard-number"
                        label="x"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        variant="filled"
                        size="small"
                        style={{ width: 100 }}
                        value={xC}
                        onChange={handleXCChange}
                    />
                    <TextField
                        id="standard-number"
                        label="y"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        variant="filled"
                        size="small"
                        style={{ width: 100, marginLeft: 10 }}
                        value={yC}
                        onChange={handleYCChange}
                    />
                    <Tooltip title="Add another creature" aria-label="add">
                        <Fab color="primary" style={{ margin: 10, width: 45, height: 40 }} onClick={handleAddCreaturePosition}>
                            <AddIcon size="small" />
                        </Fab>
                    </Tooltip>
                </Grid>
            </Grid>
            <Grid container style={{ color: "gray", marginTop: 25, marginLeft: 25 }}>
                <Typography>Moves of Zombies : {JSON.stringify(zombieMoves)}</Typography>
                <Grid item xs={12} style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    <FormControl variant="filled">
                        <Select
                            labelId="demo-simple-select-filled-label"
                            id="demo-simple-select-filled"
                            value={direction} style={{ width: 100 }} onChange={handleMoveChange}>
                            <MenuItem value={"UP"}>UP</MenuItem>
                            <MenuItem value={"DOWN"}>DOWN</MenuItem>
                            <MenuItem value={"LEFT"}>LEFT</MenuItem>
                            <MenuItem value={"RIGHT"}>RIGHT</MenuItem>
                        </Select>
                    </FormControl>
                    <Tooltip title="Add next move" aria-label="add">
                        <Fab color="primary" style={{ margin: 10, width: 45, height: 40 }} onClick={handleAddZombieMove}>
                            <AddIcon />
                        </Fab>
                    </Tooltip>
                </Grid>
            </Grid>
            <Grid container style={{ color: "gray", marginTop: 25, marginLeft: 25 }}>
                <Grid item xs={12} style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    <Button variant="outlined" color="primary" onClick={simulate}>
                        Simulate
                    </Button>
                    <Button variant="outlined" onClick={reset} style={{ marginLeft: 10 }}>Reset</Button>
                </Grid>
            </Grid>
            <br />
            {apiCallSuccess ? <Typography style={{color: "gray", textAlign: "left", marginLeft: 25}}>Zombies positions: {zombies} <br /> Creatures positions: {creatures}</Typography> : ""}
            <br />
        </>
    );
}

export default ZombieApocalypse;