function Header() {
    return (
        <h2 style={{ color: "gray", paddingTop: 10, paddingBottom: 10 }}>Zombie Apocalypse</h2>
    );
}

export default Header;