package com.ailo.zombie.application.api;

import com.ailo.zombie.application.request.Coordinate;
import com.ailo.zombie.application.request.ZombieApocalypse;
import com.ailo.zombie.application.response.ZombieApocalypseResponse;
import com.ailo.zombie.domain.service.ZombieService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Mono;

import java.util.Arrays;

import static com.ailo.zombie.application.request.Direction.*;

@ExtendWith(SpringExtension.class)
@WebFluxTest(controllers = ZombieController.class)
class ZombieControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private ZombieService zombieService;

    @Test
    void simulate() {
        ZombieApocalypse zombieApocalypse = ZombieApocalypse.builder()
                .initialZombiePosition(Coordinate.builder().x(2).y(1).build())
                .zombieMoves(Arrays.asList(UP, UP, RIGHT, DOWN))
                .initialCreaturesPosition(Arrays.asList(Coordinate.builder().x(0).y(0).build(),
                        Coordinate.builder().x(0).y(1).build(),
                        Coordinate.builder().x(0).y(4).build(),
                        Coordinate.builder().x(1).y(2).build(),
                        Coordinate.builder().x(3).y(0).build(),
                        Coordinate.builder().x(3).y(3).build(),
                        Coordinate.builder().x(4).y(1).build(),
                        Coordinate.builder().x(4).y(2).build(),
                        Coordinate.builder().x(4).y(4).build())).build();
        int[][] expectedMatrix = {{2,0,0,3,2}, {0,0,3,0,0}, {0,0,0,0,3}, {2,0,3,3,0}, {0,0,3,0,2}};
        ZombieApocalypseResponse zombieApocalypseResponse = ZombieApocalypseResponse.builder()
                .dimension(5)
                .matrix(expectedMatrix).build();

        Mockito.when(zombieService.simulate(5, zombieApocalypse)).thenReturn(Mono.just(zombieApocalypseResponse));
        webTestClient.post()
                .uri("/zombie/dimension/5")
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(zombieApocalypse))
                .exchange()
                .expectBody()
                .jsonPath("$.dimension").isEqualTo(5)
                .jsonPath("$.matrix").isArray();
    }
}