package com.ailo.zombie.domain.service;

import com.ailo.zombie.application.request.ZombieApocalypse;
import com.ailo.zombie.application.response.ZombieApocalypseResponse;
import reactor.core.publisher.Mono;

public interface ZombieService {
    Mono<ZombieApocalypseResponse> simulate(Integer dimension, ZombieApocalypse zombieWorld);
}
