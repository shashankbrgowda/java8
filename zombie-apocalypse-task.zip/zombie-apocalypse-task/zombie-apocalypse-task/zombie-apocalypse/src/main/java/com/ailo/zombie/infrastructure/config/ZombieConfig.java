package com.ailo.zombie.infrastructure.config;

import com.ailo.zombie.domain.service.ZombieService;
import com.ailo.zombie.domain.service.impl.ZombieServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ZombieConfig {
    @Bean
    public ZombieService zombieService() {
        return new ZombieServiceImpl();
    }
}
