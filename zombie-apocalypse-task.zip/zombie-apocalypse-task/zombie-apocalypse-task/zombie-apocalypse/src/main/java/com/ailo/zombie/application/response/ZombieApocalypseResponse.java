package com.ailo.zombie.application.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ZombieApocalypseResponse {
    private int dimension;
    private int[][] matrix;
}
