package com.ailo.zombie.application.api;

import com.ailo.zombie.application.request.ZombieApocalypse;
import com.ailo.zombie.application.response.ErrorResponse;
import com.ailo.zombie.application.response.ZombieApocalypseResponse;
import com.ailo.zombie.domain.service.ZombieService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
public class ZombieController {
    private final ZombieService zombieService;

    public ZombieController(ZombieService zombieService) {
        this.zombieService = zombieService;
    }

    @Operation(summary = "Simulate Zombie Apocalypse")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Simulated response",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ZombieApocalypseResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            ))})
    @CrossOrigin
    @PostMapping("zombie/dimension/{dimension}")
    @ResponseStatus(HttpStatus.OK)
    public Mono<ZombieApocalypseResponse> simulate(@PathVariable("dimension") Integer dimension, @RequestBody ZombieApocalypse zombieApocalypse) {
        return zombieService.simulate(dimension, zombieApocalypse);
    }
}
