package com.ailo.zombie.domain.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {
    public static final Integer START_ZOMBIE_POSITION_CODE = 1;
    public static final Integer END_ZOMBIE_POSITION_CODE = 3;
    public static final Integer CREATURE_POSITION_CODE = 2;
}
