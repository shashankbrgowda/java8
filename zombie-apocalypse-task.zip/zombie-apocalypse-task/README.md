# Zombie Apocalypse task (zombie-apocalypse-task)

This task contains 2 modules
- Spring boot backend which contains actual Zombie Apocalypse logic exposing an api which returns result of the simulation.
- Simple ReactJs frontend to provide input and display result from the simulation.

## Run
First run Spring boot backend (JDK 11 is required)
```aidl
cd zombie-apocalypse/
./mvnw spring-boot:run
```
Access the application at http://localhost:8080

Next run ReactJS app
```aidl
cd ../zombie-apocalypse-ui/
npm clean install
npm start
```
Access the UI at http://localhost:3000/

### Spring boot Zombie Apocalypse API (zombie-apocalypse)
Exposes api to run simulation and returns result from the simulation. Unit test cases are written for all the classes covering various scenarios.

POST zombie/dimension/{dimension}
Sample JSON Request Body:
```aidl
{
    "initialZombiePosition": {
        "x": 1,
        "y": 1
    },
    "initialCreaturesPosition": [
        {
            "x": 0,
            "y": 1
        },
        {
            "x": 2,
            "y": 2
        }
    ],
    "zombieMoves": ["UP", "UP", "RIGHT", "DOWN"]
}
```
Sample response from the API:
```aidl
{
    "dimension": 3,
    "matrix": [
        [
            0,
            0,
            3
        ],
        [
            3,
            0,
            0
        ],
        [
            0,
            0,
            3
        ]
    ]
}
```

### ReactJS Zombie Apocalypse UI (zombie-apocalypse-ui)
This simple reactjs app provides functionality to provide input for simulation, makes api call to run simulation and displays the result once simulation is complete.

![ui.png](ui.png)
