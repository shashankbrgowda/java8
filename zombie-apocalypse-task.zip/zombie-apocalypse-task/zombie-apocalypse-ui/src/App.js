import './App.css';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Header from './components/Header';
import ZombieApocalypse from './components/ZombieApocalypse';

function App() {
  return (
    <div className="App">
      <Grid container>
        <Grid item xs={3} />
        <Grid item xs={6}>
          <Paper elevation={3}>
            <Header />
            <ZombieApocalypse/>
          </Paper>
        </Grid>
        <Grid item xs={3} />
      </Grid>
    </div>
  );
}

export default App;
