package com.ailo.zombie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZombieApocalypseApplicationTests {

	@Test
	void contextLoads() {
	}

}
