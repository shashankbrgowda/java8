package com.ailo.zombie.domain.service.impl;

import com.ailo.zombie.application.request.Coordinate;
import com.ailo.zombie.application.request.ZombieApocalypse;
import com.ailo.zombie.application.response.ZombieApocalypseResponse;
import com.ailo.zombie.domain.service.ZombieService;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;

import static com.ailo.zombie.application.request.Direction.*;

class ZombieServiceImplTest {
    private ZombieService zombieService = new ZombieServiceImpl();

    @Test
    void simulate_cant_infect_any_creatures() {
        ZombieApocalypse zombieApocalypse = ZombieApocalypse.builder()
                .initialZombiePosition(Coordinate.builder().x(2).y(1).build())
                .zombieMoves(Arrays.asList(LEFT, RIGHT, UP, LEFT, DOWN, RIGHT))
                .initialCreaturesPosition(Arrays.asList(Coordinate.builder().x(0).y(0).build(),
                        Coordinate.builder().x(0).y(1).build(),
                        Coordinate.builder().x(0).y(4).build(),
                        Coordinate.builder().x(1).y(2).build(),
                        Coordinate.builder().x(3).y(0).build(),
                        Coordinate.builder().x(3).y(3).build(),
                        Coordinate.builder().x(4).y(1).build(),
                        Coordinate.builder().x(4).y(2).build(),
                        Coordinate.builder().x(4).y(4).build())).build();
        Mono<ZombieApocalypseResponse> zombieApocalypseResponse = zombieService.simulate(5, zombieApocalypse);
        int[][] expectedMatrix = {{2,2,0,0,2}, {0,0,2,0,0}, {0,3,0,0,0}, {2,0,0,2,0}, {0,2,2,0,2}};
        ZombieApocalypseResponse zombieApocalypseResponse1 = ZombieApocalypseResponse.builder()
                .dimension(5)
                .matrix(expectedMatrix).build();
        StepVerifier.create(zombieApocalypseResponse)
                .expectNext(zombieApocalypseResponse1)
                .verifyComplete();
    }

    @Test
    void simulate_infect_multiple_creatures() {
        ZombieApocalypse zombieApocalypse = ZombieApocalypse.builder()
                .initialZombiePosition(Coordinate.builder().x(2).y(1).build())
                .zombieMoves(Arrays.asList(UP, UP, RIGHT, DOWN))
                .initialCreaturesPosition(Arrays.asList(Coordinate.builder().x(0).y(0).build(),
                        Coordinate.builder().x(0).y(1).build(),
                        Coordinate.builder().x(0).y(4).build(),
                        Coordinate.builder().x(1).y(2).build(),
                        Coordinate.builder().x(3).y(0).build(),
                        Coordinate.builder().x(3).y(3).build(),
                        Coordinate.builder().x(4).y(1).build(),
                        Coordinate.builder().x(4).y(2).build(),
                        Coordinate.builder().x(4).y(4).build())).build();
        Mono<ZombieApocalypseResponse> zombieApocalypseResponse = zombieService.simulate(5, zombieApocalypse);
        int[][] expectedMatrix = {{2,0,0,3,2}, {0,0,3,0,0}, {0,0,0,0,3}, {2,0,3,3,0}, {0,0,3,0,2}};
        ZombieApocalypseResponse zombieApocalypseResponse1 = ZombieApocalypseResponse.builder()
                .dimension(5)
                .matrix(expectedMatrix).build();
        StepVerifier.create(zombieApocalypseResponse)
                .expectNext(zombieApocalypseResponse1)
                .verifyComplete();
    }

    @Test
    void simulate_infect_multiple_creatures_1() {
        ZombieApocalypse zombieApocalypse = ZombieApocalypse.builder()
                .initialZombiePosition(Coordinate.builder().x(1).y(1).build())
                .zombieMoves(Arrays.asList(UP, UP, RIGHT, DOWN))
                .initialCreaturesPosition(Arrays.asList(Coordinate.builder().x(0).y(1).build(),
                        Coordinate.builder().x(2).y(2).build())).build();
        Mono<ZombieApocalypseResponse> zombieApocalypseResponse = zombieService.simulate(3, zombieApocalypse);
        int[][] expectedMatrix = {{0,0,3}, {3,0,0}, {0,0,3}};
        ZombieApocalypseResponse zombieApocalypseResponse1 = ZombieApocalypseResponse.builder()
                .dimension(3)
                .matrix(expectedMatrix).build();
        StepVerifier.create(zombieApocalypseResponse)
                .expectNext(zombieApocalypseResponse1)
                .verifyComplete();
    }

    private boolean isEqualToExpectedMatrix(int dimension, int[][] matrix, int[][] expectedMatrix) {
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                if(matrix[i][i] != expectedMatrix[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }
}