package com.ailo.zombie.domain.service.impl;

import com.ailo.zombie.application.request.Coordinate;
import com.ailo.zombie.application.request.Direction;
import com.ailo.zombie.application.request.ZombieApocalypse;
import com.ailo.zombie.application.response.ZombieApocalypseResponse;
import com.ailo.zombie.domain.service.ZombieService;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import static com.ailo.zombie.domain.utils.Constants.*;

@Slf4j
public class ZombieServiceImpl implements ZombieService {
    /**
     * Simulate zombie apocalypse
     *
     * @param dimension   Dimension of the zombie matrix
     * @param zombieWorld ZombieWorld pojo which contains zombie initial position, creatures initial position
     *                    and moves a zombie will make
     * @return Final zombie matrix once apocalypse is over
     */
    @Override
    public Mono<ZombieApocalypseResponse> simulate(Integer dimension, ZombieApocalypse zombieWorld) {
        int[][] zombieMatrix = initializeZombieMatrix(dimension,
                zombieWorld.getInitialZombiePosition(),
                zombieWorld.getInitialCreaturesPosition());

        Queue<Coordinate> zombieDestructionQueue = new LinkedList<>();
        zombieDestructionQueue.add(zombieWorld.getInitialZombiePosition());

        int zombieCount = 0;
        while (!zombieDestructionQueue.isEmpty()) {
            Coordinate position = zombieDestructionQueue.poll();
            int x = position.getX();
            int y = position.getY();
            int xTemp = x;
            int yTemp = y;

            // Traverse as per direction and infect creatures if found
            for (Direction direction : zombieWorld.getZombieMoves()) {
                int[] adjustment = getPositionAdjustment(direction);
                int xNew = x + adjustment[0];
                int yNew = y + adjustment[1];

                if (xNew == -1) {
                    xNew = dimension - 1;
                }
                if (yNew == -1) {
                    yNew = dimension - 1;
                }
                if (xNew == dimension) {
                    xNew = 0;
                }
                if (yNew == dimension) {
                    yNew = 0;
                }

                // If the new position contains creature then convert it to Zombie and add to the Queue
                if (zombieMatrix[xNew][yNew] == CREATURE_POSITION_CODE) {
                    log.info("zombie {} infected creature at ({},{})", zombieCount, xNew, yNew);
                    zombieDestructionQueue.add(Coordinate.builder().x(xNew).y(yNew).build());
                }

                x = xNew;
                y = yNew;
                log.info("zombie {} moved to ({},{})", zombieCount, xNew, yNew);
            }

            zombieCount++;
            if (zombieMatrix[xTemp][yTemp] != END_ZOMBIE_POSITION_CODE) {
                zombieMatrix[xTemp][yTemp] = 0;
            }
            zombieMatrix[x][y] = END_ZOMBIE_POSITION_CODE;
        }

        log.info("Zombies positions: ");
        logPositions(dimension, zombieMatrix, END_ZOMBIE_POSITION_CODE);
        log.info("Creatures positions: ");
        logPositions(dimension, zombieMatrix, CREATURE_POSITION_CODE);

        return Mono.just(ZombieApocalypseResponse.builder().dimension(dimension).matrix(zombieMatrix).build())
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Log positions on to console
     *
     * @param dimension    dimension of the matrix
     * @param zombieMatrix zombie matrix with zombies and creatures
     * @param code         zombie/creature code
     */
    private void logPositions(int dimension, int[][] zombieMatrix, int code) {
        StringBuilder positions = new StringBuilder();
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (zombieMatrix[i][j] == code) {
                    positions.append("(").append(i).append(",").append(j).append(") ");
                }
            }
        }
        log.info(positions.toString());
    }

    /**
     * Get positional adjustment if zombie travels outside matrix
     *
     * @param direction Direction in which Zombie should move
     * @return positional adjustment if zombie travels outside matrix
     */
    private int[] getPositionAdjustment(Direction direction) {
        int[] adjustment;
        switch (direction) {
            case UP:
                adjustment = new int[]{-1, 0};
                break;
            case DOWN:
                adjustment = new int[]{1, 0};
                break;
            case LEFT:
                adjustment = new int[]{0, -1};
                break;
            case RIGHT:
                adjustment = new int[]{0, 1};
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + direction);
        }
        return adjustment;
    }

    /**
     * Initialize Zombie world matrix with zombies and creatures. Represented by 0,1 and 2 as below
     * 0 - Empty Position
     * 1 - Starting Zombie position
     * 2 - Occupied by Creature
     *
     * @param dimension                Dimension of the matrix, (nxn)
     * @param initialZombiePosition    Initial position of the Zombie, (x,y)
     * @param initialCreaturesPosition Initial position of the creatures
     * @return zombie matrix containing zombie and creatures
     */
    private int[][] initializeZombieMatrix(Integer dimension,
                                           Coordinate initialZombiePosition,
                                           List<Coordinate> initialCreaturesPosition) {
        int[][] zombieMatrix = new int[dimension][dimension];
        zombieMatrix[initialZombiePosition.getX()][initialZombiePosition.getY()] = START_ZOMBIE_POSITION_CODE;
        initialCreaturesPosition.forEach(coordinate -> zombieMatrix[coordinate.getX()][coordinate.getY()] = CREATURE_POSITION_CODE);
        return zombieMatrix;
    }
}
