package com.ailo.zombie.application.request;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ZombieApocalypse {
    private Coordinate initialZombiePosition;
    private List<Coordinate> initialCreaturesPosition;
    private List<Direction> zombieMoves;
}
